<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Trendystore</title>
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />

 	<style>
 		.bd-placeholder-img {
 			font-size: 1.125rem;
 			text-anchor: middle;
 			-webkit-user-select: none;
 			-moz-user-select: none;
 			user-select: none;
		}

		@media (min-width: 768px) {
			.bd-placeholder-img-lg {
				font-size: 3.5rem;
			}
		}
 	</style>



 	<link href="dashboard.css" rel="stylesheet">
 	</head>
 	<body>
 		
 <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
 	<a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Trendystore</a>
 	<button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
 		<span class="navbar-toggler-icon"></span>
 	</button>
 	<input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
 	<div class="navbar-nav">
 		<div class="nav-item text-nowrap">
 			<a class="nav-link px-3" href="#">Logout</a>
 		</div>
 	</div>
</header>

<div class="container-fluid">
	<div class="row">
		<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
			<div class="position-sticky pt-3">
				<ul class="nav flex-column">
					<li class="nav-item">
						<a class="nav-link" aria-current="page" href="index.php">
						<span data-feather="home"></span>
							Dashboard
						</a>
					</li>
				<li class="nav-item">
					<a class="nav-link active" href="databarang.php">
						<span data-feather="file"></span>
							Data Barang						
						</a>
					</li>
				</ul>
			</div>
		</nav>

		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">Data Barang</h1>
		</div>

<a href="inputdata.php" class="btn btn-primary">Input Data</a>

	<div class="card-body">

		<table id="example1" class="table table-responsive-x1 table-hover display">
			
			<thead>
				
				<tr>
					
					<th>No</th>

					<th>Kode Barang</th>

					<th>Nama Barang</th>

					<th>Harga</th>

					<th>Stok</th>

					<th>Supplier</th>

					<th>aksi</th>

				</tr>

			</thead>

			<tbody>
				
<?php				

	include 'coneksi.php';

		$no = 1;

		$number = mysqli_query($dbconnect, "SELECT * FROM barang");



		while ($query = mysqli_fetch_assoc($number)) {

?>
	
	<form  action="" method="post">
		
		   <tr>
		   	
		   	 <td><?php echo $no++;  ?></td>

		   	 <td><?php echo $query ['kode_barang']  ?></td>

		   	 <td><?php echo $query ['nama_barang']  ?></td>

		   	 <td><?php echo $query ['harga'] ?></td>

		   	 <td><?php echo $query ['stok']  ?></td>

		   	 <td><?php echo $query ['supplier']  ?></td>

		   	 <td>
		   	 	
		   	 	<a href="updatedata.php?id=<?php echo $query ['id']?>" class="btn btn-primary">Edit</a>

		   	 	<a href="proseshapusdata.php?id=<?php echo $query ['id']?>" class="btn btn-danger" onclick="return confirm ('apa kamu yakin ingin menghapus data ini?? dengan id <?php echo $query ['id']?>??')">Hapus</a>
		   	 </td>
		   </tr>

	</form>

<?php   }   ?>

				</tbody>
			</div>
		</div>
	</main>
	</div>
  </div>
		

 	
		<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
		<footer>
            
        </footer>
 	</body>
 </html>