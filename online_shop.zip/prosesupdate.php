<?php

 include 'coneksi.php';
  $id = $_POST['id'];
  $kodebarang = $_POST['kode_barang'];
  $namabarang = $_POST['nama_barang'];
  $harga = $_POST['harga'];
  $stok = $_POST['stok'];
  $supplier = $_POST['supplier'];



  mysqli_query($dbconnect, "UPDATE `barang` SET `kode_barang`='$kodebarang' , `nama_barang`='$namabarang' , `harga`='$harga' , `stok`='$stok', `supplier`='$supplier' WHERE `id`='$id' ");
  header("location:databarang.php");
  ?>