<?php include 'coneksi.php';

$id = $_POST['id'];


mysqli_query($dbconnect, "DELETE FROM akun WHERE id = '$id' "); 


header("location:dataakun.php");
?>