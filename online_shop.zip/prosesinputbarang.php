<?php

include 'coneksi.php';

$kodebarang= $_POST['kodebarang'];
$namabarang= $_POST['namabarang'];
$harga= $_POST['harga'];
$stok= $_POST['stok'];
$supplier= $_POST['supplier'];



 mysqli_query($dbconnect, "INSERT INTO barang VALUES ( NULL, '$kodebarang','$namabarang','$harga','$stok','$supplier')");

 header("location:databarang.php")
 ?>