<?php

 include 'koneksi.php';
  $no = $_POST['no'];
  $user = $_POST['user'];
  $email = $_POST['email'];
  $password = $_POST['password'];


  mysqli_query($dbconnect, "UPDATE `barang` SET `user`='$user' , `email`='$email' , `password`='$password' WHERE `no`='$no' ");
  header("location:dataakun.php");
  ?>