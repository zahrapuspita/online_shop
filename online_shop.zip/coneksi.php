<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "penjualan";

$dbconnect = new mysqli ("$host","$user","$pass","$db"); 



?>